﻿#include <iostream>
#include "tasks.h"

int main()
{
	task1();
	task2();
	return 0;
}
