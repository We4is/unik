#pragma once



void task1();
void task2();